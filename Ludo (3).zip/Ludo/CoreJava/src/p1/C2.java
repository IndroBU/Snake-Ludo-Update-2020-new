package p1;

public class C2 {

		 public static void main(String[] arg)
	      {
	    	 C1.cal(20);
	      }
	

}
